package com.bank.main;

import java.util.Scanner;

import com.bank.entity.BankDetails;
import com.bank.entity.TransactionDetails;
import com.bank.service.BankService;
import com.bank.service.Validator;

public class BankModules {
	
	Scanner scan = new Scanner(System.in);
	BankService bservice;
	BankDetails bankDetails;
	Validator validator;
	TransactionDetails transaction;
	TransactionDetails transaction2 = new TransactionDetails();

	public void createAccount() throws InvalidException {
		bservice = new BankService();
		bankDetails = new BankDetails();
		validator = new Validator();
		System.out.print("Enter Account Holder Name: ");
		String name = scan.next();
		if(validator.isNameValid(name)) {
			bankDetails.setName(name);
			System.out.print("Enter initial amount: ");
			int amount = scan.nextInt();
			if(validator.isBalanceValid(amount)) {
				bankDetails.setAccBalance(amount);
				System.out.print("Enter Mobile Number: ");
				String mobileNo = scan.next();
				bankDetails.setMobileno(mobileNo);
				bankDetails.setAccNo();
				bservice.createAccount(bankDetails);
				System.out.println("Account Created Successfully");
				int id = bankDetails.getAccNo();
				bservice.getAccountById(id);
				System.out.println("Your Account number is: " + bankDetails.getAccNo());
			}
			else {
				throw new InvalidException("Enter valid amount");
			}
		}
		else {
			throw new InvalidException("Enter valid name");
		}
	}
	
	public void showBalance() throws InvalidException {
		bservice = new BankService();
		bankDetails = new BankDetails();
		validator = new Validator();
		System.out.print("Enter your account number: ");
		int accNo = scan.nextInt();
		if (validator.isAccountNumberValid(accNo)) {
			bankDetails = bservice.getAccountById(accNo);
			System.out.println("Name: " + bankDetails.getName());
			System.out.println("Your Account Balance is: " + bankDetails.getAccBalance());
		}
		else {
			throw new InvalidException("Enter valid Account Number");
		}
	}
	
	public void deposit() throws InvalidException {
		bservice = new BankService();
		bankDetails = new BankDetails();
		validator = new Validator();
		System.out.print("Enter your Account number: ");
		int accNo = scan.nextInt();
		if (validator.isAccountNumberValid(accNo)) {
			bankDetails = bservice.getAccountById(accNo);
			System.out.println("Name: " + bankDetails.getName());
			System.out.println("Your Account Balance is: " + bankDetails.getAccBalance());
			int initBal = bankDetails.getAccBalance();
			System.out.print("Enter the Amount you want to Deposit: ");
			int depAmt = scan.nextInt();
			if(validator.isBalanceValid(depAmt)) {
				bankDetails.setAccBalance(initBal + depAmt);
				bservice.deposit(bankDetails);

				// Updating In Transaction Table
				
				transaction2.setTransactionType("Deposit");
				transaction2.setAccId(accNo);
				transaction2.setAmount(depAmt);
				bservice.addTransaction(transaction2);
				bankDetails.setT(transaction2);
				System.out.println("Your Account Balance after Depositing: " +bankDetails.getAccBalance());
			}
			else {
				throw new InvalidException("Enter valid amount");
			}
		}
		else {
			throw new InvalidException("Enter valid Account number");
		}
	}
	
	public void withdraw() throws InvalidException {
		bservice = new BankService();
		bankDetails = new BankDetails();
		validator = new Validator();
		System.out.print("Enter your Account number: ");
		int accNo = scan.nextInt();
		if (validator.isAccountNumberValid(accNo)) {
			bankDetails = bservice.getAccountById(accNo);
			System.out.println(" Your Account Balance is: " + bankDetails.getAccBalance());
			int initBal = bankDetails.getAccBalance(); // initial balance
			
			System.out.print("Enter the Amount you to Withdraw: ");
			int amount = scan.nextInt();
			
			if(validator.isBalanceValid(amount) && (initBal>amount)) {
				bankDetails.setAccBalance(initBal - amount);
				bservice.withdraw(bankDetails);

				// Updating In Transaction Table
				
				transaction2.setTransactionType("Withdraw");
				transaction2.setAccId(accNo);
				transaction2.setAmount(amount);
				bservice.addTransaction(transaction2);
				bankDetails.setT(transaction2);

				bankDetails = bservice.getAccountById(accNo);
				System.out.println("Hello " + bankDetails.getName());
				System.out.println("Your Remaining Account Balance after Withdraw: " +bankDetails.getAccBalance());
			}
			else {
				throw new InvalidException("Enter valid Amount");
			}
		}
		else {
			throw new InvalidException("Enter valid Account Number");
		}
	}
	
	public void fundTransfer() throws InvalidException {
		bservice = new BankService();
		bankDetails = new BankDetails();
		validator = new Validator();
		transaction = new TransactionDetails();
		System.out.print("Enter the Sender Account Number: ");
		int senderAccNo = scan.nextInt(); // From Account Id (Sender)
		if (validator.isAccountNumberValid(senderAccNo)) {
			bankDetails = bservice.getAccountById(senderAccNo);
			int senderBalance = bankDetails.getAccBalance(); // Initial Balance
			System.out.println("Enter the amount you want to transfer");
			int amount = scan.nextInt(); // Amount to be transfered
			if(validator.isBalanceValid(amount)) {
				
				System.out.print("Enter Reciever Account Number: ");
				int recAccNo = scan.nextInt();
				
				if (validator.isAccountNumberValid(recAccNo)) {
					// Removing the Balance transfered from sender Account
					
					bankDetails = bservice.getAccountById(senderAccNo);
					int remBalance = senderBalance - amount;
					bankDetails.setAccBalance(remBalance);
					bservice.deposit(bankDetails);

					// updating the Balance recieved from Sender
					
					bankDetails = bservice.getAccountById(recAccNo);
					int initBalance = bankDetails.getAccBalance();
					int updateBalance = initBalance + amount;
					bankDetails.setAccBalance(updateBalance);
					bservice.deposit(bankDetails);

					// updating In transaction Table
					
					transaction.setTransactionType("Transfered to " + recAccNo);
					transaction.setAccId(senderAccNo);
					transaction.setAmount(amount);
					bservice.addTransaction(transaction);
					bankDetails.setT(transaction);
					int a = transaction.getTransactionId();

					/*
					 * //Updating In transaction Table trans1.setTransactionId(a);
					 * trans1.setTransactionType("Recieved From"+fid); trans1.setAccId(tid);
					 * trans1.setAmount(fund); service.addTransaction(trans1); bank.setT(trans1);
					 * 
					 */

					bankDetails = bservice.getAccountById(senderAccNo);
					System.out.println("Remaining balance in account " +bankDetails.getAccBalance());
				}
				else {
					throw new InvalidException("Enter valid Account Number");
				}
			}
			else {
				throw new InvalidException("Enter valid Amount");
			}
		}
		else {
			throw new InvalidException("Enter Valid Account Number");
		}
	}
	
	public void printTransactions() throws InvalidException {
		bservice = new BankService();
		validator = new Validator();
		System.out.print("Enter Account number: ");
		int accNo = scan.nextInt();
		if(validator.isAccountNumberValid(accNo)) {
			bservice.printTransactions(accNo);
		}
		else {
			throw new InvalidException("Enter Valid Account Number");
		}
	}
	
}
