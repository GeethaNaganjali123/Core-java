package com.bank.dao;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class Dao_Test {
	BankDAO bd = new BankDAO();
	
	@Test
	public void Search()
	{
		assertTrue("This will succeed.", true);
		//assertTrue("This will fail!", false);
	}

}
