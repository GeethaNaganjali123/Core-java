package demo;
interface Sum{
	int calcSum(int x);
}

abstract class SumClass implements Sum{
	public int clacSum(int x) {
		int res=x+10;
		return res;
	}
}
public class LamdaDemo {
public static void main(String args[]) {
	Sum s=(v)->v+10;
	int c=s.calcSum(23);
	System.out.println(c);
}
}
