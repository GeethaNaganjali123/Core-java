package demo;

public class Block {
	{
	System.out.println("nonstatic");
}
static {
	System.out.println("static");
}
public static void main(String args[]) {
	//Block obj=new Block();
	//Block obj1=new Block();
}

}
