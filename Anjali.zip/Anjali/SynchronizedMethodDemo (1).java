package demo;
class SynMethod{
	void display() {
		System.out.println(Thread.currentThread().getName());
		for(int i=0;i<5;i++) {
			System.out.println(i);
			try {
				Thread.sleep(6000);
			}catch(InterruptedException e)
			{
				System.out.println(e);
				}
			}
	}
}
public class SynchronizedMethodDemo implements Runnable {
	SynMethod mObj;
	SynchronizedMethodDemo(SynMethod m,String name){
		mObj=m;
		Thread t=new Thread(this,name);
		t.start();
		
		
	}
	public void run() {
		mObj.display();
	}
	public static void main(String args[]) {
		SynMethod mObj=new SynMethod();
		SynchronizedMethodDemo s1=new SynchronizedMethodDemo(mObj,"Thread hi");
		SynchronizedMethodDemo s2=new SynchronizedMethodDemo(mObj,"Thread hello");
		SynchronizedMethodDemo s3=new SynchronizedMethodDemo(mObj,"Thread hey");
	
	}

}
