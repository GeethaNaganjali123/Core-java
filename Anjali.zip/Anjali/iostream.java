package demo;
import java.io.*;
public class iostream{
	public void readRAF() throws IOException{
		try {
			RandomAccessFile rafObj=new RandomAccessFile("C:\\Users\\rosbalaj\\Desktop\\roshni\\read.txt","r");
			String a;
			while((a=rafObj.readLine())!=null) {
				//rafObj.writeChars(a);
				RandomAccessFile obj=new RandomAccessFile("C:\\Users\\rosbalaj\\Desktop\\roshni\\write.txt","rw");
				obj.writeChars(a+"roshni");
				obj.close();
			}
			rafObj.close();
		}
		catch(Exception e) {
			System.out.println(e);
		}
		}
	/*public void writeRaf()throws IOException{
		try {
			RandomAccessFile rafObj=new RandomAccessFile("C:\\Users\\rosbalaj\\Desktop\\roshni\\write.txt","rw");
			rafObj.writeChars("hello");
			rafObj.close();
			
		}catch(Exception e) {
			System.out.println(e);
		}
	}*/
	public static void main(String args[])throws IOException{
		iostream rafObj=new iostream();
		rafObj.readRAF();
		iostream obj=new iostream();
	obj.readRAF();
		
	}
	}


