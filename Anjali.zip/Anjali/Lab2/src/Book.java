


public class Book extends WrittenItem
{

	public Book(int id, String title, int copies) {
		super(id, title, copies);
		// TODO Auto-generated constructor stub
	}
}

	



