package com.bean;
import java.util.*;
public class Employee {
	private int empId;
	private String name;
	private int salary;
	private String des;
	public String getDes() {
		return des;
	}



	public void setDes(String des) {
		this.des = des;
	}
	private String scheme;
	



	public String getScheme() {
		return scheme;
	}



	public void setScheme(String scheme) {
		this.scheme = scheme;
	}



	@Override
	public String toString() {
		
		return "Employee ID is:" + empId + ", Employee Name is :" + name + ", Employee Salary is:" + salary+"emp Role is :" + des +"emp scheme is :" + scheme  ;
	}

	
	
	public Employee(int empid, String name, int sal,String des,String scheme) {
		// TODO Auto-generated constructor stub
		this.empId = empid;
		this.name = name;
		this.salary = sal;
		this.des=des;
		this.scheme=scheme;
	}

	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}


}
