package demo;

import java.text.NumberFormat;
import java.util.Locale;

public class NumberFormatDemo {
	public static void main(String args[]) {
		Locale locale=new Locale("da","DK");
		NumberFormat numberFormat=NumberFormat.getInstance();
		System.out.println(numberFormat.format(10000099));
		NumberFormat currencyFormat=NumberFormat.getCurrencyInstance();
		System.out.println(currencyFormat.format(10000099));
		
	}

}
