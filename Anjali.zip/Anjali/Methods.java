package com.employeeBean;
import com.employeeUi.*;
public class Methods {
	int empid;
	String employeename;
	float employeesalary;
	float insuranceamt;	
	public Methods(int empid) {
		this.empid=empid;
	}
	public Methods(int empid, String employeename, int employeesalary) {
		this.empid= empid;
		this.employeename= employeename;
		this.employeesalary=employeesalary;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmployeename() {
		return employeename;
	}
	public void setEmployeename(String employeename) {
		this.employeename = employeename;
	}
	public float getEmployeesalary() {
		return employeesalary;
	}
	public void setEmployeesalary(float employeesalary) {
		this.employeesalary = employeesalary;
	}
	public float getInsuranceamt() {
		return insuranceamt;
	}
	public void setInsuranceamt(float insuranceamt) {
		this.insuranceamt = insuranceamt;
	}
	
	
	
	
}
